# PPML and Heavy-Tailed Trade Flows — Python replication

Replication code for *"PPML and Heavy-Tailed Trade Flows: Why Standard Inference
Fails and How to Fix It"* (Egger, Ji, and Wang).

This package contains exactly two self-contained scripts. Each inlines every
helper it needs (the PPML estimator, fixed-effect profiling, sandwich and
cluster standard errors, and the country-level bootstrap); neither imports the
other.

```
ppmlmn_python/
├── ppmlmn_simulation.py   # the simulation  (Tables 2-3)
├── ppmlmn_empirical.py    # the applications (Tables 4–7)
├── data/                  # the six source CSVs (already here)
└── README.md
```

**Dependencies:** Python 3.8+, NumPy (both scripts) and pandas (empirical only).

```bash
pip install numpy pandas
```

## Simulation — `ppmlmn_simulation.py`

Reproduces the two-way fixed-effect coverage comparison (Table 3): Monte Carlo
coverage of nominal 95% intervals for the treatment coefficient, HC0 sandwich
vs. the country-level *m*-out-of-*n* bootstrap, across tail indices
α ∈ {2.0, 1.8, 1.5, 1.2}. The α = 2.0 row is a finite-variance benchmark
(unit-mean lognormal shock); the heavy rows use unit-mean Pareto(α). The
bootstrap draws G = ⌊N^0.7⌋ countries and refits PPML on the induced subnetwork.

```bash
python ppmlmn_simulation.py            # default: 1000 reps/cell, M=149
python ppmlmn_simulation.py --quick    # fast check
python ppmlmn_simulation.py --reps 2000 --M 149
```

Writes `simulation_results.csv`. The paper computes the sandwich column over
6,000 replications and the bootstrap column over 600–1,300 (each replication
entails M PPML refits); raise `--reps` to tighten the Monte Carlo error.

## Applications — `ppmlmn_empirical.py`

Estimates two-way FE PPML for every application panel and reports, per
coefficient, the HC0, one-way-cluster (exporter), two-way-cluster
(exporter+importer), and country-level bootstrap intervals.

```bash
python ppmlmn_empirical.py                 # all panels, M=2000
python ppmlmn_empirical.py --M 500         # faster
python ppmlmn_empirical.py --panels cs_A,fdi
```

Writes `empirical_results.csv`. Panels: `cs_A`/`cs_B` (ICIO aggregate),
`use_A/B_final/inter` (final/intermediate use), `migration`, `fdi`. To point at
data elsewhere, set `PPMLMN_DATA=/path/to/data`.

## Reproducibility

Within Python, both scripts are reproducible given the seed (defaults: empirical
42, simulation 20240101). Point estimates and HC0 endpoints match the paper to
estimation tolerance; the dense regressor (`ln_dist`) matches the reported
digits, while sparse dummies can differ by ≤0.04 across solvers because a few
subnetwork draws drop a collinear dummy differently. The companion MATLAB
package gives the same results in distribution but is not seed-identical (NumPy
uses PCG64, MATLAB uses Mersenne-Twister).

## Data

| file | contents |
|------|----------|
| `gravity_covariates.csv` | `iso_o, iso_d, ln_dist, contig, comlang_off, colony` |
| `icio_country_pair_year.csv` | ICIO total bilateral sales by year |
| `icio_country_pair_year_final.csv` | final-demand component |
| `icio_country_pair_year_inter.csv` | intermediate component |
| `bilat_mig.csv` | bilateral migration (`da_pb_closed`) |
| `fdi_bilateral_2022.csv` | bilateral FDI stock |
