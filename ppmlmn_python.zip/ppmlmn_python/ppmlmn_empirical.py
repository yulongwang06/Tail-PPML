"""
ppmlmn_empirical.py
===================
Self-contained empirical replication for "PPML and Heavy-Tailed Trade Flows:
Why Standard Inference Fails and How to Fix It" (Egger, Ji, and Wang).

Estimates two-way fixed-effect PPML gravity models for the paper's applications
and, for every coefficient, reports four 95% confidence intervals:
    HC0 sandwich, one-way cluster (exporter), two-way cluster
    (exporter+importer), and the country-level m-out-of-n bootstrap.

Panels (built from the CSVs in ./data):
    cs_A, cs_B            ICIO aggregate bilateral sales, 2022
    use_A/B_final/inter   final / intermediate use decomposition
    migration             bilateral migration, 2015
    fdi                   bilateral FDI stock, 2015

Everything needed is in this one file; dependencies are NumPy and pandas.

Usage
-----
    python ppmlmn_empirical.py                  # all panels, M=2000
    python ppmlmn_empirical.py --M 500          # faster
    python ppmlmn_empirical.py --panels cs_A,fdi
Set the environment variable PPMLMN_DATA to point at the data folder if it is
not ./data next to this script.
"""
import argparse
import os
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
Z = 1.959963984540054


# =====================================================================
# 1. PPML with two-way fixed effects (Sinkhorn profiling + Newton)
# =====================================================================
def _codes(a):
    u, inv = np.unique(np.asarray(a), return_inverse=True)
    return inv.astype(np.int64), len(u)


def _group_lse(codes, vals, K):
    """Numerically stable log(sum_j exp(vals_j)) within each group code in
    [0, K). Subtracting the per-group max keeps every exponential in [0, 1],
    so heavy-tailed flows no longer overflow exp() in the FE-profiling step."""
    m = np.full(K, -np.inf)
    np.maximum.at(m, codes, vals)
    out = np.full(K, -np.inf)
    ok = np.isfinite(m)
    s = np.bincount(codes, np.exp(vals - m[codes]), K)
    out[ok] = m[ok] + np.log(s[ok])
    return out


def _sep_mask(y, oc, dc):
    """Iteratively drop observations whose origin or destination has a zero
    outcome total (PPML separation); return a boolean keep mask."""
    keep = np.ones(len(y), bool)
    while True:
        ock, Ko = _codes(oc[keep]); dck, Kd = _codes(dc[keep])
        yk = y[keep]
        bad_o = np.bincount(ock, yk, Ko) <= 0
        bad_d = np.bincount(dck, yk, Kd) <= 0
        if not bad_o.any() and not bad_d.any():
            break
        drop_local = bad_o[ock] | bad_d[dck]
        idx = np.where(keep)[0][drop_local]
        if idx.size == 0:
            break
        keep[idx] = False
    return keep


def ppml_2way(y, X, oc, dc, maxit=250, tol=1e-10, sink=60, proj=100):
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    if X.ndim == 1:
        X = X[:, None]
    oc = np.asarray(oc); dc = np.asarray(dc)
    keep = _sep_mask(y, oc, dc)                       # drop separated observations
    y, X, oc, dc = y[keep], X[keep], oc[keep], dc[keep]
    n, p = X.shape
    if n < p + 4:
        return None
    oc, Ko = _codes(oc); dc, Kd = _codes(dc)
    Ro = np.bincount(oc, y, Ko); Cd = np.bincount(dc, y, Kd)
    if np.any(Ro <= 0) or np.any(Cd <= 0):
        return None
    logRo, logCd = np.log(Ro), np.log(Cd)
    la = np.zeros(Ko); lb = np.zeros(Kd); beta = np.zeros(p)
    A = np.zeros((Ko, p)); B = np.zeros((Kd, p))
    H = np.eye(p); mu = y.copy()
    for _ in range(maxit):
        xb = X @ beta
        if not np.all(np.isfinite(xb)) or np.max(np.abs(xb)) > 300:
            return None
        for _ in range(sink):
            la = logRo - _group_lse(oc, lb[dc] + xb, Ko)
            lb_new = logCd - _group_lse(dc, la[oc] + xb, Kd)
            if np.max(np.abs(lb_new - lb)) < 1e-12:
                lb = lb_new
                break
            lb = lb_new
        mu = np.exp(la[oc] + lb[dc] + xb)
        smo = np.bincount(oc, mu, Ko); smd = np.bincount(dc, mu, Kd)
        for _ in range(proj):
            A = (np.vstack([np.bincount(oc, mu * (X[:, k] - B[dc, k]), Ko)
                            for k in range(p)]).T) / smo[:, None]
            Bn = (np.vstack([np.bincount(dc, mu * (X[:, k] - A[oc, k]), Kd)
                             for k in range(p)]).T) / smd[:, None]
            if np.max(np.abs(Bn - B)) < 1e-13:
                B = Bn
                break
            B = Bn
        Xt = X - A[oc] - B[dc]
        g = Xt.T @ (y - mu)
        H = (Xt * mu[:, None]).T @ Xt
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            ridge = 1e-9 * (np.trace(H) / p + 1e-12)
            try:
                step = np.linalg.solve(H + ridge * np.eye(p), g)
            except np.linalg.LinAlgError:
                return None
        mxs = np.max(np.abs(X @ step))
        if mxs > 10:
            step = step * (10.0 / mxs)
        t = 1.0
        for _ in range(40):
            if np.max(np.abs(X @ (beta + t * step))) <= 250:
                break
            t *= 0.5
        beta = beta + t * step
        if np.max(np.abs(t * step)) < tol:
            break
    res = y - mu
    try:
        Hi = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        return None
    meat = (Xt * (res ** 2)[:, None]).T @ Xt
    V_hc0 = Hi @ meat @ Hi
    K = p + (Ko - 1) + (Kd - 1) + 1
    if n <= K:                                        # no residual dof for a sandwich
        return None
    dof = n / (n - K)
    return {"beta": beta, "Xt": Xt, "res": res, "Hi": Hi, "n": n, "p": p,
            "Ko": Ko, "Kd": Kd, "keep": keep,
            "se_hc0": np.sqrt(np.diag(V_hc0)),
            "se_hc1": np.sqrt(np.diag(V_hc0) * dof)}


# =====================================================================
# 2. CRV1 cluster-robust standard errors (one-way or two-way)
# =====================================================================
def cluster_se(fit, cl):
    Xt, res, Hi, n, p = fit["Xt"], fit["res"], fit["Hi"], fit["n"], fit["p"]
    K = p + (fit["Ko"] - 1) + (fit["Kd"] - 1)
    adj = (n - 1) / (n - K)
    s = Xt * res[:, None]

    def crv(c):
        c, G = _codes(c)
        meat = np.zeros((p, p))
        for g in range(G):
            sg = s[c == g].sum(0)
            meat += np.outer(sg, sg)
        return Hi @ meat @ Hi

    if not isinstance(cl, (list, tuple)):
        V = crv(cl)
    else:
        c1, c2 = cl
        c12 = np.array([f"{a}|{b}" for a, b in zip(c1, c2)])
        V = crv(c1) + crv(c2) - crv(c12)
    return np.sqrt(np.diag(V) * adj)


# =====================================================================
# 3. Country-level m-out-of-n bootstrap (multi-coefficient)
#    Draws G = floor(N^0.7) countries, refits PPML on the induced
#    subnetwork, and self-normalizes by the subsample sandwich. On a
#    separated/collinear subnetwork the sparsest active covariate is
#    dropped and the fit retried, mirroring fixest/pyfixest.
# =====================================================================
def country_bootstrap(y, X, oc, dc, M=2000, seed=42, tau=0.05,
                      studentizer="hc1", G=None):
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    if X.ndim == 1:
        X = X[:, None]
    p = X.shape[1]
    fit = ppml_2way(y, X, oc, dc)
    keep = fit["keep"]
    y, X, oc, dc = y[keep], X[keep], np.asarray(oc)[keep], np.asarray(dc)[keep]
    beta = fit["beta"]; se = fit["se_" + studentizer]
    countries = np.unique(np.concatenate([oc, dc]))
    cidx = {c: i for i, c in enumerate(countries)}
    N = len(countries)
    if G is None:
        G = int(np.floor(N ** 0.7))
    oci = np.array([cidx[c] for c in oc]); dci = np.array([cidx[c] for c in dc])
    rng = np.random.default_rng(seed)
    T = [[] for _ in range(p)]
    for _ in range(M):
        pick = rng.choice(N, size=G, replace=False)
        inp = np.zeros(N, bool); inp[pick] = True
        m = inp[oci] & inp[dci]
        ys, Xs, os, ds = y[m], X[m], oci[m], dci[m]
        if ys.shape[0] < p + 5:                        # subnetwork too sparse to fit
            continue
        active = [k for k in range(p) if np.ptp(Xs[:, k]) > 0]

        def _frag(k):
            u = np.unique(Xs[:, k])
            return min((Xs[:, k] == v).sum() for v in u) if len(u) <= 3 else len(Xs)

        frag = {k: _frag(k) for k in active}
        while active:
            fj = ppml_2way(ys, Xs[:, active], os, ds)
            if fj is None:
                active.pop(int(np.argmin([frag[k] for k in active])))
                continue
            sj = fj["se_" + studentizer]; bj = fj["beta"]
            bad = [i for i in range(len(active))
                   if not (np.isfinite(bj[i]) and sj[i] > 0 and np.isfinite(sj[i]))]
            if bad:
                worst = bad[int(np.argmin([frag[active[i]] for i in bad]))]
                active.pop(worst)
                continue
            for ka, k in enumerate(active):
                T[k].append((bj[ka] - beta[k]) / sj[ka])
            break
    lo = np.full(p, np.nan); hi = np.full(p, np.nan); nrep = np.zeros(p, int)
    for k in range(p):
        t = np.asarray(T[k]); nrep[k] = t.size
        if t.size >= 20:
            qlo, qhi = np.quantile(t, tau / 2), np.quantile(t, 1 - tau / 2)
            lo[k] = beta[k] - qhi * se[k]; hi[k] = beta[k] - qlo * se[k]
    return {"beta": beta, "se": se, "lo": lo, "hi": hi, "nrep": nrep, "N": N, "G": G}


# =====================================================================
# 4. Build the eight estimation panels from ./data
# =====================================================================
_HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("PPMLMN_DATA", os.path.join(_HERE, "data"))
CV4 = ["ln_dist", "contig", "comlang_off", "colony"]


def _path(name):
    return os.path.join(DATA_DIR, name)


def datasets():
    cov = pd.read_csv(_path("gravity_covariates.csv"))

    def merge(df):
        d = df.merge(cov, left_on=["origin", "destination"],
                     right_on=["iso_o", "iso_d"], how="inner")
        d["flow"] = d["flow"].clip(lower=0)
        d["internal"] = (d.origin == d.destination).astype(int)
        return d

    out = {}
    icio = (pd.read_csv(_path("icio_country_pair_year.csv"))
            .query("year==2022 and origin!='ROW' and destination!='ROW'"))
    agg = merge(icio)
    out["cs_A"] = (agg[agg.origin != agg.destination].copy(), CV4)
    out["cs_B"] = (agg.copy(), CV4 + ["internal"])

    fin = (pd.read_csv(_path("icio_country_pair_year_final.csv"))
           .query("year==2022").rename(columns={"flow": "fin"}))
    itr = (pd.read_csv(_path("icio_country_pair_year_inter.csv"))
           .query("year==2022").rename(columns={"flow": "itr"}))
    m = (agg.merge(fin[["origin", "destination", "fin"]], on=["origin", "destination"], how="left")
            .merge(itr[["origin", "destination", "itr"]], on=["origin", "destination"], how="left"))
    m["fin"] = m["fin"].fillna(0).clip(lower=0)
    m["itr"] = m["itr"].fillna(0).clip(lower=0)
    mA = m[m.origin != m.destination].copy()
    out["use_A_final"] = (mA.assign(flow=mA["fin"]).copy(), CV4)
    out["use_A_inter"] = (mA.assign(flow=mA["itr"]).copy(), CV4)
    out["use_B_final"] = (m.assign(flow=m["fin"]).copy(), CV4 + ["internal"])
    out["use_B_inter"] = (m.assign(flow=m["itr"]).copy(), CV4 + ["internal"])

    mig = (pd.read_csv(_path("bilat_mig.csv"))
           .rename(columns={"orig": "origin", "dest": "destination"}))
    mig = mig[mig.year0 == 2015].copy()
    mig["flow"] = mig["da_pb_closed"].clip(lower=0)
    mig = mig[mig.origin != mig.destination]
    out["migration"] = (mig.merge(cov, left_on=["origin", "destination"],
                                  right_on=["iso_o", "iso_d"], how="inner").copy(), CV4)

    fdi = pd.read_csv(_path("fdi_bilateral_2022.csv"))
    fdi = fdi[fdi.year == 2015]
    fdi = fdi[fdi.origin != fdi.destination].copy()
    fdi["flow"] = fdi["fdi_stock"].clip(lower=0)
    out["fdi"] = (fdi.merge(cov, left_on=["origin", "destination"],
                            right_on=["iso_o", "iso_d"], how="inner").copy(), CV4)
    return out


# =====================================================================
# 5. Estimate every panel and report the four interval types
# =====================================================================
def run(M=2000, seed=42, panels=None, studentizer="hc1"):
    D = datasets()
    keys = panels if panels else list(D.keys())
    unknown = [k for k in keys if k not in D]
    if unknown:
        print(f"[warn] unknown panel(s) ignored: {', '.join(unknown)}")
        keys = [k for k in keys if k in D]
    if not keys:
        print(f"No panels to estimate. Available: {', '.join(D.keys())}")
        return []
    # The first reported interval is the conventional sandwich. Its scaling is
    # set by --studentizer: hc0 is the plain sandwich, hc1 applies the n/(n-K)
    # dof factor (the fixest/pyfixest default). Label the column and CSV fields
    # with the studentizer actually used so the name never misstates the value.
    slab = studentizer.upper()
    rows = []
    for name in keys:
        d, cv = D[name]
        y = d["flow"].to_numpy(float); X = d[cv].to_numpy(float)
        oc = d["origin"].to_numpy(); dc = d["destination"].to_numpy()
        fit = ppml_2way(y, X, oc, dc)
        if fit is None:
            print(f"[skip] {name}: PPML did not converge")
            continue
        keep = fit["keep"]
        ocf, dcf = oc[keep], dc[keep]
        b = fit["beta"]; se0 = fit["se_" + studentizer]
        c1 = cluster_se(fit, ocf); c2 = cluster_se(fit, [ocf, dcf])
        bs = country_bootstrap(y, X, oc, dc, M=M, seed=seed, studentizer=studentizer)
        N = len(set(ocf) | set(dcf))
        print(f"\n=== {name}  n={fit['n']}  N={N}  G={bs['G']} ===")
        print(f"{'covar':12s} {'coef':>8} {slab:>16} {'clu1':>16} "
              f"{'clu2':>16} {'bootstrap':>16}")
        for k, nm in enumerate(cv):
            hc = (b[k] - Z * se0[k], b[k] + Z * se0[k])
            cl1 = (b[k] - Z * c1[k], b[k] + Z * c1[k])
            cl2 = (b[k] - Z * c2[k], b[k] + Z * c2[k])
            bw = (bs["lo"][k], bs["hi"][k])
            wr = (bw[1] - bw[0]) / (hc[1] - hc[0])
            print(f"{nm:12s} {b[k]:8.3f} [{hc[0]:6.3f},{hc[1]:6.3f}] "
                  f"[{cl1[0]:6.3f},{cl1[1]:6.3f}] [{cl2[0]:6.3f},{cl2[1]:6.3f}] "
                  f"[{bw[0]:6.3f},{bw[1]:6.3f}]  (boot/{slab}={wr:.2f}x)")
            rows.append({"table": name, "covar": nm, "n": fit["n"], "N": N, "G": bs["G"],
                         "coef": round(b[k], 4),
                         f"{studentizer}_lo": round(hc[0], 4),
                         f"{studentizer}_hi": round(hc[1], 4),
                         "clu1_lo": round(cl1[0], 4), "clu1_hi": round(cl1[1], 4),
                         "clu2_lo": round(cl2[0], 4), "clu2_hi": round(cl2[1], 4),
                         "boot_lo": round(bw[0], 4), "boot_hi": round(bw[1], 4),
                         "boot_nrep": int(bs["nrep"][k]),
                         f"boot_over_{studentizer}": round(wr, 3)})
    if not rows:
        print("No results produced (all selected panels were skipped).")
        return []
    out = os.path.join(_HERE, "empirical_results.csv")
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"\nwrote {out}  ({len(rows)} coefficient rows)")
    return rows


def main():
    ap = argparse.ArgumentParser(description="PPML gravity applications with country bootstrap.")
    ap.add_argument("--M", type=int, default=2000, help="bootstrap subsamples")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--panels", type=str, default="", help="comma-separated subset")
    ap.add_argument("--studentizer", choices=["hc0", "hc1"], default="hc1")
    a = ap.parse_args()
    pl = [p for p in a.panels.split(",") if p] or None
    run(M=a.M, seed=a.seed, panels=pl, studentizer=a.studentizer)


if __name__ == "__main__":
    main()
