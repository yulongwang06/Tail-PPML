"""
ppmlmn_simulation.py
====================
Self-contained simulation for "PPML and Heavy-Tailed Trade Flows: Why Standard
Inference Fails and How to Fix It" (Egger, Ji, and Wang).

Replicates BOTH Monte Carlo tables in one file:

  Table 2  Empirical coverage of the nominal 95% HC0 sandwich CI for the
           treatment coefficient beta_1, under three treatment designs (A, B, C),
           across N in {50,75,100} and tail indices alpha in {2.0,1.8,1.5,1.2}.
           Sandwich only (no bootstrap), so it runs quickly.

  Table 3  Monte Carlo coverage of nominal 95% CIs for beta_1 under two-way
           fixed effects, comparing the HC0 sandwich with the country-level
           m-out-of-n bootstrap, at N=50 across the same alpha grid.

Both tables use the SAME dyadic two-way fixed-effect gravity DGP:
    mu_ij = exp(fe_ex_i + fe_im_j + beta1 * Treat_ij),   beta1 = 0.5,
with bounded exporter/importer effects ~ U(-1,1) and a multiplicative,
unit-mean shock that is Pareto(alpha) for alpha<2 and a finite-variance
lognormal benchmark (Var=0.25) at alpha=2. The tables differ only in:
  * the treatment covariate Treat (Table 2 varies its design A/B/C;
    Table 3 uses a binary treatment active on 20% of pairs), and
  * whether the country-level bootstrap is also computed (Table 3 only).

Treatment designs (Table 2):
    A (symmetric baseline): Treat ~ N(0,1)          i.i.d.
    B (bounded covariate) : Treat ~ U[0,4]          i.i.d.
    C (sparse binary)     : Treat = 1 on 2% of pairs, else 0
Treatment (Table 3):
    binary treatment active on 20% of pairs.

The only dependency is NumPy.

Usage
-----
    python ppmlmn_simulation.py                 # both tables, paper-style
    python ppmlmn_simulation.py --table 2       # Table 2 only
    python ppmlmn_simulation.py --table 3       # Table 3 only
    python ppmlmn_simulation.py --quick         # fast check
    python ppmlmn_simulation.py --reps 2000 --M 149 --N 50
"""
import argparse
import time
import numpy as np


# =====================================================================
# 1. PPML with two-way (exporter/importer) fixed effects   [shared core]
#    Sinkhorn matrix-balancing profiles the fixed effects given beta;
#    Newton-Raphson updates beta. Returns beta and HC0/HC1 sandwich SEs.
# =====================================================================
def _codes(a):
    u, inv = np.unique(np.asarray(a), return_inverse=True)
    return inv.astype(np.int64), len(u)


def _group_lse(codes, vals, K):
    """Numerically stable log(sum_j exp(vals_j)) within each group code in
    [0, K). Subtracting the per-group max keeps every exponential in [0, 1],
    so heavy-tailed flows no longer overflow exp() in the FE-profiling step."""
    m = np.full(K, -np.inf)
    np.maximum.at(m, codes, vals)
    out = np.full(K, -np.inf)
    ok = np.isfinite(m)
    s = np.bincount(codes, np.exp(vals - m[codes]), K)
    out[ok] = m[ok] + np.log(s[ok])
    return out


def ppml_2way(y, X, oc, dc, maxit=250, tol=1e-10, sink=60, proj=100):
    """Two-way FE Poisson PPML (p>=1 regressors). Returns dict or None."""
    y = np.asarray(y, float)
    X = np.asarray(X, float)
    if X.ndim == 1:
        X = X[:, None]
    n, p = X.shape
    oc, Ko = _codes(oc)
    dc, Kd = _codes(dc)
    Ro = np.bincount(oc, y, Ko)
    Cd = np.bincount(dc, y, Kd)
    if np.any(Ro <= 0) or np.any(Cd <= 0):
        return None
    logRo, logCd = np.log(Ro), np.log(Cd)
    la = np.zeros(Ko); lb = np.zeros(Kd); beta = np.zeros(p)
    A = np.zeros((Ko, p)); B = np.zeros((Kd, p))
    H = np.eye(p); mu = y.copy()
    for _ in range(maxit):
        xb = X @ beta
        if not np.all(np.isfinite(xb)) or np.max(np.abs(xb)) > 300:
            return None
        for _ in range(sink):                       # profile the FEs (Poisson FOC)
            la = logRo - _group_lse(oc, lb[dc] + xb, Ko)
            lb_new = logCd - _group_lse(dc, la[oc] + xb, Kd)
            if np.max(np.abs(lb_new - lb)) < 1e-12:
                lb = lb_new
                break
            lb = lb_new
        mu = np.exp(la[oc] + lb[dc] + xb)
        smo = np.bincount(oc, mu, Ko); smd = np.bincount(dc, mu, Kd)
        for _ in range(proj):                       # residualize X in the mu-metric
            A = (np.vstack([np.bincount(oc, mu * (X[:, k] - B[dc, k]), Ko)
                            for k in range(p)]).T) / smo[:, None]
            Bn = (np.vstack([np.bincount(dc, mu * (X[:, k] - A[oc, k]), Kd)
                             for k in range(p)]).T) / smd[:, None]
            if np.max(np.abs(Bn - B)) < 1e-13:
                B = Bn
                break
            B = Bn
        Xt = X - A[oc] - B[dc]
        g = Xt.T @ (y - mu)
        H = (Xt * mu[:, None]).T @ Xt
        try:
            step = np.linalg.solve(H, g)
        except np.linalg.LinAlgError:
            ridge = 1e-9 * (np.trace(H) / p + 1e-12)
            try:
                step = np.linalg.solve(H + ridge * np.eye(p), g)
            except np.linalg.LinAlgError:
                return None
        mxs = np.max(np.abs(X @ step))              # cap per-iteration index change
        if mxs > 10:
            step = step * (10.0 / mxs)
        t = 1.0
        for _ in range(40):                          # damping: keep index bounded
            if np.max(np.abs(X @ (beta + t * step))) <= 250:
                break
            t *= 0.5
        beta = beta + t * step
        if np.max(np.abs(t * step)) < tol:
            break
    res = y - mu
    try:
        Hi = np.linalg.inv(H)
    except np.linalg.LinAlgError:
        return None
    meat = (Xt * (res ** 2)[:, None]).T @ Xt
    V_hc0 = Hi @ meat @ Hi
    K = p + (Ko - 1) + (Kd - 1) + 1
    if n <= K:                                      # no residual dof for a sandwich
        return None
    dof = n / (n - K)
    return {"beta": beta, "se_hc0": np.sqrt(np.diag(V_hc0)),
            "se_hc1": np.sqrt(np.diag(V_hc0) * dof)}


# =====================================================================
# 2. Country-level m-out-of-n bootstrap for the treatment coefficient
#    (Table 3 only)
# =====================================================================
def country_bootstrap_coef(y, X, oci, dci, Nc, beta0, se_full, G, M, rng,
                           studentizer="hc0", tau=0.05):
    """Return (lo, hi) bootstrap CI for the single coefficient, or (nan, nan)."""
    key = "se_" + studentizer
    T = []
    for _ in range(M):
        pick = rng.choice(Nc, size=G, replace=False)
        inp = np.zeros(Nc, bool); inp[pick] = True
        msk = inp[oci] & inp[dci]
        ys, Xs, os, ds = y[msk], X[msk], oci[msk], dci[msk]
        if ys.size < 5 or np.ptp(Xs) == 0:             # empty/tiny or no variation
            continue
        fj = ppml_2way(ys, Xs, os, ds)
        if fj is None:
            continue
        bj, sj = fj["beta"][0], fj[key][0]
        if sj > 0 and np.isfinite(sj) and np.isfinite(bj):
            T.append((bj - beta0) / sj)
    if len(T) < 20:
        return np.nan, np.nan
    T = np.asarray(T)
    qlo, qhi = np.quantile(T, tau / 2), np.quantile(T, 1 - tau / 2)
    return beta0 - qhi * se_full, beta0 - qlo * se_full


# =====================================================================
# 3. Data-generating process: dyadic two-way FE gravity   [shared]
#    mu_ij = exp(fe_ex_i + fe_im_j + beta1 * Treat_ij), bounded effects and a
#    bounded treatment; multiplicative heavy-tailed shock.
# =====================================================================
def make_pairs(N):
    ii, jj = np.where(~np.eye(N, dtype=bool))
    return ii.astype(np.int64), jj.astype(np.int64)


def shock(rng, n, alpha):
    """Unit-mean multiplicative shock: Pareto(alpha) if alpha<2; finite-variance
    lognormal benchmark (Var=0.25) at alpha=2 (used for both tables)."""
    if alpha < 2.0:
        return rng.random(n) ** (-1.0 / alpha) * (alpha - 1.0) / alpha
    s = np.sqrt(np.log(1.25)); mu = -0.5 * s * s
    return np.exp(mu + s * rng.standard_normal(n))


def draw_treatment(treat, n, rng):
    """Treatment covariate for the n off-diagonal directed pairs.
       'A' -> N(0,1); 'B' -> U[0,4]; 'C' -> binary 2% (Table 2);
       'binary20' -> binary 20% (Table 3)."""
    if treat == "A":
        return rng.standard_normal(n)
    if treat == "B":
        return rng.uniform(0.0, 4.0, n)
    if treat == "C":
        return (rng.random(n) < 0.02).astype(float)
    if treat == "binary20":
        return (rng.random(n) < 0.20).astype(float)
    raise ValueError(treat)


def gen_dgp(N, oci, dci, alpha, rng, treat, beta1=0.5, fe_scale=1.0):
    """One replication of the two-way FE gravity DGP. Returns (y, Treat)."""
    n = len(oci)
    fe_o = rng.uniform(-fe_scale, fe_scale, N)
    fe_i = rng.uniform(-fe_scale, fe_scale, N)
    D = draw_treatment(treat, n, rng)
    mu = np.exp(fe_o[oci] + fe_i[dci] + beta1 * D)
    y = mu * shock(rng, n, alpha)
    return y, D


# =====================================================================
# 4. Table 2: sandwich coverage across designs A/B/C, N, and alpha
# =====================================================================
def run_table2(Ns=(50, 75, 100), reps=2000, alphas=(2.0, 1.8, 1.5, 1.2),
               beta1=0.5, studentizer="hc0", seed=20240101):
    Z = 1.959963984540054
    key = "se_" + studentizer
    designs = ("A", "B", "C")
    dname = {"A": "A:symmetric", "B": "B:bounded", "C": "C:sparse-bin"}
    print(f"\n=== Table 2 : sandwich coverage of nominal 95% CI for beta1={beta1} "
          f"(reps={reps}, studentizer={studentizer}) ===")
    print(f"{'design':>13} {'alpha':>6}" + "".join(f"  N={N:<7d}" for N in Ns))
    rows = []
    for design in designs:
        for alpha in alphas:
            covs = []
            for N in Ns:
                oci, dci = make_pairs(N)
                cellseed = (seed + 1009 * (ord(design) - ord("A"))
                            + 101 * int(round(alpha * 10)) + N)
                rng = np.random.default_rng(cellseed)
                cov = v = 0
                for _ in range(reps):
                    y, D = gen_dgp(N, oci, dci, alpha, rng, design, beta1=beta1)
                    fit = ppml_2way(y, D, oci, dci)
                    if fit is None:
                        continue
                    b = fit["beta"][0]; se = fit[key][0]
                    if not (np.isfinite(b) and se > 0):
                        continue
                    v += 1
                    cov += (b - Z * se <= beta1 <= b + Z * se)
                covs.append(cov / v if v else float("nan"))
            print(f"{dname[design]:>13} {alpha:6.1f}" +
                  "".join(f"  {c:8.3f}" for c in covs))
            rows.append((design, alpha, *covs))
    return rows, Ns


# =====================================================================
# 5. Table 3: sandwich vs. country-level bootstrap coverage (N=50)
# =====================================================================
def run_table3(N=50, reps=1000, M=149, alphas=(2.0, 1.8, 1.5, 1.2),
               beta1=0.5, studentizer="hc0", seed=20240101):
    oci, dci = make_pairs(N)
    n = len(oci); G = int(np.floor(N ** 0.7))
    Z = 1.959963984540054
    key = "se_" + studentizer
    print(f"\n=== Table 3 : two-way FE coverage, sandwich vs. country bootstrap "
          f"(N={N}, n={n}, G={G}, reps={reps}, M={M}, {studentizer}) ===")
    print(f"{'alpha':>7} {'shock':>10} {'sandwich':>10} {'country_boot':>13} {'valid':>7}")
    rows = []
    for ai, alpha in enumerate(alphas):
        rng = np.random.default_rng(seed + 101 * ai)
        cs = cb = v = 0
        for _ in range(reps):
            y, D = gen_dgp(N, oci, dci, alpha, rng, "binary20", beta1=beta1)
            fit = ppml_2way(y, D, oci, dci)
            if fit is None:
                continue
            b = fit["beta"][0]; se = fit[key][0]
            if not (np.isfinite(b) and se > 0):
                continue
            v += 1
            cs += (b - Z * se <= beta1 <= b + Z * se)
            lo, hi = country_bootstrap_coef(y, D, oci, dci, N, b, se, G, M, rng,
                                            studentizer=studentizer)
            if np.isfinite(lo):
                cb += (lo <= beta1 <= hi)
        lab = "lognormal" if alpha >= 2.0 else "Pareto"
        cov_s = cs / v if v else float("nan")
        cov_b = cb / v if v else float("nan")
        if v == 0:
            print(f"{alpha:7.2f} {lab:>10} {'n/a':>10} {'n/a':>13} {v:7d}")
        else:
            print(f"{alpha:7.2f} {lab:>10} {cov_s:10.3f} {cov_b:13.3f} {v:7d}")
        rows.append((alpha, lab,
                     round(cov_s, 3) if v else None,
                     round(cov_b, 3) if v else None, v))
    return rows


# =====================================================================
# 6. Command-line entry point
# =====================================================================
def _write_csv(path, header, rows):
    import csv
    with open(path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)


def main():
    ap = argparse.ArgumentParser(
        description="Two-way FE PPML coverage simulation (Tables 2 and 3).")
    ap.add_argument("--table", choices=["2", "3", "both"], default="both",
                    help="which table(s) to run")
    ap.add_argument("--reps", type=int, default=None, help="MC replications per cell")
    ap.add_argument("--M", type=int, default=149, help="Table 3 bootstrap refits")
    ap.add_argument("--N", type=int, default=50, help="Table 3 number of countries")
    ap.add_argument("--Ns", type=int, nargs="+", default=[50, 75, 100],
                    help="Table 2 country counts")
    ap.add_argument("--quick", action="store_true", help="fast check (few reps)")
    ap.add_argument("--studentizer", choices=["hc0", "hc1"], default="hc0")
    ap.add_argument("--seed", type=int, default=20240101)
    a = ap.parse_args()
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    t0 = time.time()

    if a.table in ("2", "both"):
        reps2 = a.reps if a.reps is not None else (150 if a.quick else 2000)
        rows, Ns = run_table2(Ns=tuple(a.Ns), reps=reps2,
                              studentizer=a.studentizer, seed=a.seed)
        _write_csv(os.path.join(here, "simulation_results_table2.csv"),
                   ["design", "alpha"] + [f"cov_N{N}" for N in Ns],
                   [[r[0], r[1]] + [round(x, 3) for x in r[2:]] for r in rows])
        print("wrote simulation_results_table2.csv")

    if a.table in ("3", "both"):
        reps3 = a.reps if a.reps is not None else (150 if a.quick else 1000)
        M = 99 if a.quick else a.M
        rows = run_table3(N=a.N, reps=reps3, M=M,
                          studentizer=a.studentizer, seed=a.seed)
        _write_csv(os.path.join(here, "simulation_results_table3.csv"),
                   ["alpha", "shock", "cov_sandwich", "cov_country_boot", "reps"],
                   rows)
        print("wrote simulation_results_table3.csv")

    print(f"\n[{(time.time()-t0)/60:.1f} min]")
    print("Note: coverage cells carry Monte Carlo standard error "
          "~sqrt(p(1-p)/reps); raise --reps to tighten.\n"
          "The paper computes the Table 3 sandwich column over ~6,000 reps and "
          "the bootstrap over 600-1,300 reps.")


if __name__ == "__main__":
    main()
