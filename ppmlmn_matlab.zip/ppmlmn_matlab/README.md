# PPML and Heavy-Tailed Trade Flows — MATLAB replication

Replication code for *"PPML and Heavy-Tailed Trade Flows: Why Standard Inference
Fails and How to Fix It"* (Egger, Ji, and Wang).

This package contains exactly two self-contained function files. Each inlines
every helper it needs (the PPML estimator, fixed-effect profiling, sandwich and
cluster standard errors, the country-level bootstrap, and — for the empirical
file — the data construction). No shared files, no toolboxes.

```
ppmlmn_matlab/
├── ppmlmn_simulation.m   # the simulation  (Tables 2-3)
├── ppmlmn_empirical.m    # the applications (Tables 4-7)
├── data/                 # the six source CSVs (already here)
└── README.md
```

**Requirements:** MATLAB R2016b+ (base install; no toolboxes). Also runs on a
recent Octave. From the package folder:

## Simulation — `ppmlmn_simulation.m`

Reproduces the two-way fixed-effect coverage comparison (Table 3): nominal-95%
coverage for the treatment coefficient, HC0 sandwich vs. the country-level
m-out-of-n bootstrap, across tail indices alpha in {2.0,1.8,1.5,1.2}. The
alpha=2 row is a finite-variance benchmark (unit-mean lognormal shock); the
heavy rows use unit-mean Pareto(alpha). The bootstrap draws G = floor(N^0.7)
countries and refits PPML on the induced subnetwork.

```matlab
ppmlmn_simulation                      % default: 1000 reps/cell, M=149
ppmlmn_simulation('quick', true)       % fast check
ppmlmn_simulation('reps',2000,'M',149)
```

Writes `simulation_results.csv`. The paper computes the sandwich column over
6,000 replications and the bootstrap column over 600-1,300; raise `reps` to
tighten the Monte Carlo error.

## Applications — `ppmlmn_empirical.m`

Estimates two-way FE PPML for every application panel and reports, per
coefficient, the HC0, one-way-cluster (exporter), two-way-cluster
(exporter+importer), and country-level bootstrap intervals.

```matlab
ppmlmn_empirical                       % all panels, M=2000
ppmlmn_empirical('M', 500)             % faster
ppmlmn_empirical('panels', {'cs_A','fdi'})
```

Writes `empirical_results.csv`. Panels: cs_A/cs_B (ICIO aggregate),
use_A/B_final/inter (final/intermediate use), migration, fdi. Pass
`'data_dir','/path/to/data'` if the CSVs are elsewhere.

## Reproducibility

Within MATLAB, both files are reproducible given the seed (defaults: empirical
42, simulation 20240101). The companion Python package gives the same results
in distribution but is not seed-identical across languages: MATLAB uses the
Mersenne-Twister RNG and NumPy uses PCG64. Point estimates and HC0 endpoints
match the paper to estimation tolerance; the dense regressor (ln_dist) matches
the reported digits, while sparse dummies can differ by <=0.04 across solvers
because a few subnetwork draws drop a collinear dummy differently.

## Data

| file | contents |
|------|----------|
| `gravity_covariates.csv` | iso_o, iso_d, ln_dist, contig, comlang_off, colony |
| `icio_country_pair_year.csv` | ICIO total bilateral sales by year |
| `icio_country_pair_year_final.csv` | final-demand component |
| `icio_country_pair_year_inter.csv` | intermediate component |
| `bilat_mig.csv` | bilateral migration (da_pb_closed) |
| `fdi_bilateral_2022.csv` | bilateral FDI stock |
