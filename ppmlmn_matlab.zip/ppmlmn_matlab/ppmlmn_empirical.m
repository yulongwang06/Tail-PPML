function ppmlmn_empirical(varargin)
%PPMLMN_EMPIRICAL  Empirical replication for "PPML and Heavy-Tailed Trade
%  Flows: Why Standard Inference Fails and How to Fix It" (Egger, Ji, and Wang).
%  Self-contained: every helper (PPML estimator, cluster SEs, country-level
%  bootstrap, data construction) is a local function in this file. Base MATLAB;
%  no toolboxes required. Reads the CSVs in ./data.
%
%  For each application panel and coefficient it reports four 95% intervals:
%  HC0 sandwich, one-way cluster (exporter), two-way cluster
%  (exporter+importer), and the country-level m-out-of-n bootstrap.
%
%  Usage:
%    ppmlmn_empirical
%    ppmlmn_empirical('M',500,'seed',42)
%    ppmlmn_empirical('panels',{'cs_A','fdi'})

ip = inputParser;
addParameter(ip,'M',2000); addParameter(ip,'seed',42);
addParameter(ip,'studentizer','hc1'); addParameter(ip,'panels',{});
addParameter(ip,'data_dir','');
parse(ip,varargin{:}); o = ip.Results;
Z = 1.959963984540054;

here = fileparts(mfilename('fullpath'));
if isempty(o.data_dir), o.data_dir = fullfile(here,'data'); end
D = build_data(o.data_dir);
allnames = {D.name};
if ~isempty(o.panels)
    missing = setdiff(string(o.panels), string(allnames));
    if ~isempty(missing)
        warning('ppmlmn:unknownPanel', 'unknown panel(s) ignored: %s', ...
            strjoin(cellstr(missing), ', '));
    end
    D = D(ismember(allnames, o.panels));
end
if isempty(D)
    fprintf('No panels to estimate. Available: %s\n', strjoin(allnames, ', '));
    return;
end

slab = upper(o.studentizer);
rows = {}; hdr = {'table','covar','n','N','G','coef', ...
    [o.studentizer '_lo'], [o.studentizer '_hi'], ...
    'clu1_lo','clu1_hi','clu2_lo','clu2_hi','boot_lo','boot_hi','boot_nrep', ...
    ['boot_over_' o.studentizer]};
for i = 1:numel(D)
    d = D(i);
    fit = ppml_2way(d.y, d.X, d.oc, d.dc);
    if isempty(fit), fprintf('[skip] %s\n', d.name); continue; end
    keep = fit.keep; ocf = d.oc(keep); dcf = d.dc(keep);
    b = fit.beta; se0 = fit.(['se_' o.studentizer]);
    c1 = cluster_se(fit, ocf);
    c2 = cluster_se(fit, {ocf, dcf});
    bs = country_bootstrap(d.y, d.X, d.oc, d.dc, o.M, o.seed, o.studentizer);
    N = numel(unique([string(ocf(:)); string(dcf(:))]));
    fprintf('\n=== %s   n=%d  N=%d  G=%d ===\n', d.name, fit.n, N, bs.G);
    fprintf('%-12s %8s %16s %16s %16s %16s\n','covar','coef',slab,'clu1','clu2','bootstrap');
    for k = 1:numel(d.covars)
        hc = [b(k)-Z*se0(k), b(k)+Z*se0(k)];
        cl1 = [b(k)-Z*c1(k), b(k)+Z*c1(k)];
        cl2 = [b(k)-Z*c2(k), b(k)+Z*c2(k)];
        bw = [bs.lo(k), bs.hi(k)];
        wr = (bw(2)-bw(1)) / (hc(2)-hc(1));
        fprintf('%-12s %8.3f [%6.3f,%6.3f] [%6.3f,%6.3f] [%6.3f,%6.3f] [%6.3f,%6.3f] (%.2fx)\n', ...
            d.covars{k}, b(k), hc(1),hc(2), cl1(1),cl1(2), cl2(1),cl2(2), bw(1),bw(2), wr);
        rows(end+1,:) = {d.name, d.covars{k}, fit.n, N, bs.G, round(b(k),4), ...
            round(hc(1),4),round(hc(2),4), round(cl1(1),4),round(cl1(2),4), ...
            round(cl2(1),4),round(cl2(2),4), round(bw(1),4),round(bw(2),4), ...
            bs.nrep(k), round(wr,3)}; %#ok<AGROW>
    end
end
if isempty(rows)
    fprintf('No results produced (all selected panels were skipped).\n');
    return;
end
T = cell2table(rows, 'VariableNames', hdr);
writetable(T, fullfile(here,'empirical_results.csv'));
fprintf('\nwrote empirical_results.csv  (%d rows)\n', height(T));
end


% =====================================================================
%  Grouped log-sum-exp  (numerically stable FE profiling)
% =====================================================================
function out = group_lse(c, v, K)
% log(sum_j exp(v_j)) within each group code c in 1..K. Subtracting the
% per-group max keeps every exponential in [0,1], so heavy-tailed flows no
% longer overflow exp() in the Sinkhorn step.
m = accumarray(c, v, [K 1], @max, -inf);
out = m + log(accumarray(c, exp(v - m(c)), [K 1]));
end


% =====================================================================
%  Build the eight estimation panels from ./data
% =====================================================================
function D = build_data(data_dir)
P = @(f) fullfile(data_dir, f);
CV4 = {'ln_dist','contig','comlang_off','colony'};
cov = readtable(P('gravity_covariates.csv'), 'TextType','string');
D = struct('name',{},'y',{},'X',{},'oc',{},'dc',{},'covars',{});

icio = readtable(P('icio_country_pair_year.csv'), 'TextType','string');
icio = icio(icio.year==2022 & icio.origin~="ROW" & icio.destination~="ROW", :);
agg = merge_cov(icio, cov);
agg.internal = double(agg.origin == agg.destination);
intl = agg(agg.origin ~= agg.destination, :);
D(end+1) = panel('cs_A', intl, CV4);
D(end+1) = panel('cs_B', agg, [CV4 {'internal'}]);

fin = readtable(P('icio_country_pair_year_final.csv'), 'TextType','string'); fin = fin(fin.year==2022,:);
itr = readtable(P('icio_country_pair_year_inter.csv'), 'TextType','string'); itr = itr(itr.year==2022,:);
finflow = lookup_flow(agg, fin); itrflow = lookup_flow(agg, itr);
isA = agg.origin ~= agg.destination;
D(end+1) = panel_y('use_A_final', agg(isA,:), CV4, finflow(isA));
D(end+1) = panel_y('use_A_inter', agg(isA,:), CV4, itrflow(isA));
D(end+1) = panel_y('use_B_final', agg, [CV4 {'internal'}], finflow);
D(end+1) = panel_y('use_B_inter', agg, [CV4 {'internal'}], itrflow);

mig = readtable(P('bilat_mig.csv'), 'TextType','string');
mig = mig(mig.year0==2015, :);
mig.origin = mig.orig; mig.destination = mig.dest;
mig.flow = max(mig.da_pb_closed, 0);
mig = mig(mig.origin ~= mig.destination, :);
D(end+1) = panel('migration', merge_cov(mig, cov), CV4);

fdi = readtable(P('fdi_bilateral_2022.csv'), 'TextType','string');
fdi = fdi(fdi.year==2015 & fdi.origin~=fdi.destination, :);
fdi.flow = max(fdi.fdi_stock, 0);
D(end+1) = panel('fdi', merge_cov(fdi, cov), CV4);
end

function out = merge_cov(T, cov)
kT = T.origin + "|" + T.destination;
kC = cov.iso_o + "|" + cov.iso_d;
[tf, loc] = ismember(kT, kC);
out = T(tf, :); covm = cov(loc(tf), :);
for vname = {'ln_dist','contig','comlang_off','colony'}
    out.(vname{1}) = covm.(vname{1});
end
out.flow = max(out.flow, 0);
end

function flow = lookup_flow(base, src)
kB = base.origin + "|" + base.destination;
kS = src.origin + "|" + src.destination;
[tf, loc] = ismember(kB, kS);
flow = zeros(height(base),1);
flow(tf) = max(src.flow(loc(tf)), 0);
end

function s = panel(name, T, covars)
X = zeros(height(T), numel(covars));
for k = 1:numel(covars), X(:,k) = T.(covars{k}); end
s = struct('name',name,'y',T.flow,'X',X,'oc',T.origin,'dc',T.destination,'covars',{covars});
end

function s = panel_y(name, T, covars, yvec)
X = zeros(height(T), numel(covars));
for k = 1:numel(covars), X(:,k) = T.(covars{k}); end
s = struct('name',name,'y',yvec(:),'X',X,'oc',T.origin,'dc',T.destination,'covars',{covars});
end


% =====================================================================
%  Two-way FE Poisson PPML
% =====================================================================
function fit = ppml_2way(y, X, oc, dc)
y = y(:); if isvector(X), X = X(:); end
keep = sep_mask(y, oc, dc);
y = y(keep); X = X(keep,:); oc = oc(keep); dc = dc(keep);
[n,p] = size(X);
if n < p + 4, fit = []; return; end
[oc,Ko] = codes(oc); [dc,Kd] = codes(dc);
Ro = accumarray(oc, y, [Ko 1]); Cd = accumarray(dc, y, [Kd 1]);
if any(Ro <= 0) || any(Cd <= 0), fit = []; return; end
logRo = log(Ro); logCd = log(Cd);
la = zeros(Ko,1); lb = zeros(Kd,1); beta = zeros(p,1);
A = zeros(Ko,p); B = zeros(Kd,p); H = eye(p); mu = y; Xt = X;
for it = 1:250
    xb = X*beta;
    if any(~isfinite(xb)) || max(abs(xb)) > 300, fit = []; return; end
    for s = 1:60
        la = logRo - group_lse(oc, lb(dc) + xb, Ko);
        lb_new = logCd - group_lse(dc, la(oc) + xb, Kd);
        if max(abs(lb_new - lb)) < 1e-12, lb = lb_new; break; end
        lb = lb_new;
    end
    mu = exp(la(oc) + lb(dc) + xb);
    smo = accumarray(oc, mu, [Ko 1]); smd = accumarray(dc, mu, [Kd 1]);
    for j = 1:100
        for k = 1:p
            A(:,k) = accumarray(oc, mu.*(X(:,k) - B(dc,k)), [Ko 1]) ./ smo;
        end
        Bn = B;
        for k = 1:p
            Bn(:,k) = accumarray(dc, mu.*(X(:,k) - A(oc,k)), [Kd 1]) ./ smd;
        end
        if max(abs(Bn(:) - B(:))) < 1e-13, B = Bn; break; end
        B = Bn;
    end
    Xt = X - A(oc,:) - B(dc,:);
    g = Xt'*(y - mu); H = (Xt .* mu)' * Xt;
    [step,ok] = safe_solve(H, g, p);
    if ~ok, fit = []; return; end
    mxs = max(abs(X*step)); if mxs > 10, step = step*(10/mxs); end
    t = 1;
    for d = 1:40
        if max(abs(X*(beta + t*step))) <= 250, break; end
        t = t/2;
    end
    beta = beta + t*step;
    if max(abs(t*step)) < 1e-10, break; end
end
res = y - mu;
if any(~isfinite(H(:))) || rcond(H) < 1e-15, fit = []; return; end
Hi = inv(H);
V = Hi*((Xt .* (res.^2))'*Xt)*Hi;
K = p + (Ko-1) + (Kd-1) + 1;
if n <= K, fit = []; return; end          % no residual dof for a sandwich
dof = n/(n-K);
fit = struct('beta',beta,'Xt',Xt,'res',res,'Hi',Hi,'n',n,'p',p,'Ko',Ko,'Kd',Kd, ...
    'oc',oc,'dc',dc,'keep',keep,'se_hc0',sqrt(diag(V)),'se_hc1',sqrt(diag(V)*dof));
end


% =====================================================================
%  CRV1 cluster-robust SE (one-way or two-way)
% =====================================================================
function se = cluster_se(fit, cl)
Xt = fit.Xt; res = fit.res; Hi = fit.Hi; n = fit.n; p = fit.p;
K = p + (fit.Ko - 1) + (fit.Kd - 1);
adj = (n - 1) / (n - K);
s = Xt .* res;
if ~iscell(cl)
    V = crv1(s, Hi, p, cl);
else
    c12 = strcat(string(cl{1}(:)), "|", string(cl{2}(:)));
    V = crv1(s,Hi,p,cl{1}) + crv1(s,Hi,p,cl{2}) - crv1(s,Hi,p,c12);
end
se = sqrt(diag(V)*adj);
end

function V = crv1(s, Hi, p, c)
[~,~,c] = unique(c); c = c(:); G = max(c);
meat = zeros(p,p);
for g = 1:G
    sg = sum(s(c==g,:),1);
    meat = meat + (sg'*sg);
end
V = Hi*meat*Hi;
end


% =====================================================================
%  Country-level m-out-of-n bootstrap (multi-coefficient)
% =====================================================================
function bs = country_bootstrap(y, X, oc, dc, M, seed, stud)
y = y(:); if isvector(X), X = X(:); end
p = size(X,2);
fit = ppml_2way(y, X, oc, dc);
keep = fit.keep;
y = y(keep); X = X(keep,:); oc = oc(keep); dc = dc(keep);
beta = fit.beta; se = fit.(['se_' stud]);
allc = [string(oc(:)); string(dc(:))];
[~, ~, allcode] = unique(allc);
oci = allcode(1:numel(oc)); dci = allcode(numel(oc)+1:end);
N = max(allcode); G = floor(N^0.7);
rng(seed, 'twister');
T = cell(p,1); for k=1:p, T{k} = []; end
for j = 1:M
    pick = randperm(N, G); inp = false(N,1); inp(pick) = true;
    msk = inp(oci) & inp(dci);
    ys = y(msk); Xs = X(msk,:); os = oci(msk); ds = dci(msk);
    if numel(ys) < p + 5, continue; end                   % subnetwork too sparse to fit
    active = find((max(Xs,[],1) - min(Xs,[],1)) > 0);
    if isempty(active), continue; end
    frag = containers.Map('KeyType','double','ValueType','double');
    for k = active
        u = unique(Xs(:,k));
        if numel(u) <= 3, frag(k) = min(arrayfun(@(v) sum(Xs(:,k)==v), u));
        else, frag(k) = numel(ys); end
    end
    while ~isempty(active)
        fj = ppml_2way(ys, Xs(:,active), os, ds);
        if isempty(fj)
            [~,wi] = min(arrayfun(@(k) frag(k), active)); active(wi) = []; continue;
        end
        sj = fj.(['se_' stud]); bj = fj.beta;
        bad = find(~(isfinite(bj) & sj > 0 & isfinite(sj)));
        if ~isempty(bad)
            [~,wi] = min(arrayfun(@(k) frag(active(k)), bad)); active(bad(wi)) = []; continue;
        end
        for ka = 1:numel(active)
            T{active(ka)}(end+1) = (bj(ka) - beta(active(ka))) / sj(ka);
        end
        break;
    end
end
lo = nan(p,1); hi = nan(p,1); nrep = zeros(p,1);
for k = 1:p
    t = T{k}(:); nrep(k) = numel(t);
    if numel(t) >= 20
        lo(k) = beta(k) - qtile(t,0.975)*se(k);
        hi(k) = beta(k) - qtile(t,0.025)*se(k);
    end
end
bs = struct('beta',beta,'se',se,'lo',lo,'hi',hi,'nrep',nrep,'N',N,'G',G);
end


% =====================================================================
%  Small utilities
% =====================================================================
function [c,K] = codes(a)
[~,~,c] = unique(a); c = c(:); K = max(c);
end

function keep = sep_mask(y, oc, dc)
% Iteratively drop observations whose origin or destination has a zero
% outcome total (PPML separation); return a logical keep mask.
y = y(:); keep = true(numel(y),1);
while true
    [~,~,ock] = unique(oc(keep)); [~,~,dck] = unique(dc(keep));
    yk = y(keep);
    bad_o = accumarray(ock, yk, [max(ock) 1]) <= 0;
    bad_d = accumarray(dck, yk, [max(dck) 1]) <= 0;
    if ~any(bad_o) && ~any(bad_d), break; end
    drop_local = bad_o(ock) | bad_d(dck);
    idx = find(keep); idx = idx(drop_local);
    if isempty(idx), break; end
    keep(idx) = false;
end
end

function [step,ok] = safe_solve(H, g, p)
ok = true;
[Rc,flag] = chol(H);
if flag == 0, step = Rc \ (Rc' \ g); return; end
ridge = 1e-9*(trace(H)/p + 1e-12);
step = (H + ridge*eye(p)) \ g;
if any(~isfinite(step)), ok = false; step = zeros(p,1); end
end

function q = qtile(x, p)
x = sort(x(:)); m = numel(x);
if m == 0, q = NaN; return; end
h = (m-1)*p + 1; lo = floor(h);
if lo >= m, q = x(m); return; end
q = x(lo) + (h - lo)*(x(lo+1) - x(lo));
end
