function ppmlmn_simulation(varargin)
%PPMLMN_SIMULATION  Two-way FE PPML coverage simulation (Tables 2 and 3) for
%  "PPML and Heavy-Tailed Trade Flows: Why Standard Inference Fails and How to
%  Fix It" (Egger, Ji, and Wang). Self-contained: every helper is a local
%  function in this file. Runs in base MATLAB or Octave; no toolboxes required.
%
%  Replicates BOTH Monte Carlo tables:
%    Table 2  Empirical coverage of the nominal 95% HC0 sandwich CI for beta_1
%             under three treatment designs (A,B,C), across N in {50,75,100}
%             and alpha in {2.0,1.8,1.5,1.2}. Sandwich only (fast).
%    Table 3  Coverage of nominal 95% CIs for beta_1 under two-way FE at N=50,
%             comparing the HC0 sandwich with the country-level m-out-of-n
%             bootstrap (G=floor(N^0.7) countries), across the same alpha grid.
%
%  Both tables use the SAME dyadic two-way FE gravity DGP:
%    mu_ij = exp(fe_ex_i + fe_im_j + beta1*Treat_ij),  beta1 = 0.5,
%  with fe ~ U(-1,1) and a unit-mean shock: Pareto(alpha) for alpha<2 and a
%  finite-variance lognormal benchmark (Var=0.25) at alpha=2. They differ only
%  in the treatment covariate and whether the bootstrap is also computed:
%    Table 2 designs: A ~ N(0,1); B ~ U[0,4]; C = binary on 2% of pairs.
%    Table 3        : binary treatment on 20% of pairs (sandwich + bootstrap).
%
%  Usage:
%    ppmlmn_simulation                                  % both tables
%    ppmlmn_simulation('table','2')                     % Table 2 only
%    ppmlmn_simulation('table','3')                     % Table 3 only
%    ppmlmn_simulation('reps',2000,'M',149,'N',50)
%    ppmlmn_simulation('quick',true)
%
%  Note: MATLAB uses Mersenne-Twister; the Python twin uses PCG64, so results
%  match in distribution but not seed-for-seed across languages.

ip = inputParser;
addParameter(ip,'table','both'); addParameter(ip,'reps',[]);
addParameter(ip,'M',149); addParameter(ip,'N',50);
addParameter(ip,'Ns',[50 75 100]); addParameter(ip,'quick',false);
addParameter(ip,'studentizer','hc0'); addParameter(ip,'seed',20240101);
parse(ip,varargin{:}); o = ip.Results;

if any(strcmp(o.table,{'2','both'})), run_table2(o); end
if any(strcmp(o.table,{'3','both'})), run_table3(o); end
end

% =====================================================================
%  Table 2 : sandwich coverage across designs A/B/C, N, and alpha
% =====================================================================
function run_table2(o)
if isempty(o.reps), reps = 2000; else, reps = o.reps; end
if o.quick, reps = 150; end
Ns = o.Ns; Z = 1.959963984540054; b1 = 0.5;
alphas = [2.0 1.8 1.5 1.2];
designs = {'A','B','C'};
dname = {'A:symmetric','B:bounded','C:sparse-bin'};

fprintf('\n=== Table 2 : sandwich coverage of nominal 95%% CI for beta1=%.2f (reps=%d, %s) ===\n', ...
        b1, reps, o.studentizer);
fprintf('%13s %6s', 'design','alpha');
for iN = 1:numel(Ns), fprintf('   N=%-6d', Ns(iN)); end
fprintf('\n');

R = {};
for id = 1:numel(designs)
    d = designs{id};
    for ai = 1:numel(alphas)
        a = alphas(ai);
        covs = zeros(1,numel(Ns));
        for iN = 1:numel(Ns)
            N = Ns(iN); [oci,dci] = make_pairs(N);
            cellseed = o.seed + 1009*(double(d)-double('A')) + 101*round(a*10) + N;
            rng(cellseed,'twister');
            cov = 0; v = 0;
            for r = 1:reps
                [y,X] = gen_dgp(N, oci, dci, a, d, b1);
                f = ppml_2way(y, X, oci, dci);
                if isempty(f), continue; end
                b = f.beta(end); se = f.(['se_' o.studentizer])(end);
                if ~(isfinite(b) && se > 0), continue; end
                v = v + 1;
                cov = cov + (b - Z*se <= b1 && b1 <= b + Z*se);
            end
            if v > 0, covs(iN) = cov/v; else, covs(iN) = NaN; end
        end
        fprintf('%13s %6.1f', dname{id}, a);
        for iN = 1:numel(Ns), fprintf('   %8.3f', covs(iN)); end
        fprintf('\n');
        R(end+1,:) = [{d, a}, num2cell(covs)]; %#ok<AGROW>
    end
end
hdr = [{'design','alpha'}, arrayfun(@(N) sprintf('cov_N%d',N), Ns, 'uni', 0)];
write_results_csv(fullfile(fileparts(mfilename('fullpath')), ...
    'simulation_results_table2.csv'), hdr, R);
fprintf('wrote simulation_results_table2.csv\n');
end

% =====================================================================
%  Table 3 : sandwich vs. country-level bootstrap coverage (N=50)
% =====================================================================
function run_table3(o)
if isempty(o.reps), reps = 1000; else, reps = o.reps; end
M = o.M;
if o.quick, reps = 150; M = 99; end
N = o.N; [oci,dci] = make_pairs(N); n = numel(oci);
G = floor(N^0.7); Z = 1.959963984540054; b1 = 0.5;
alphas = [2.0 1.8 1.5 1.2];

fprintf('\n=== Table 3 : two-way FE coverage, sandwich vs. country bootstrap (N=%d, n=%d, G=%d, reps=%d, M=%d, %s) ===\n', ...
        N, n, G, reps, M, o.studentizer);
fprintf('%7s %10s %10s %13s %7s\n','alpha','shock','sandwich','country_boot','valid');
R = {};
for ai = 1:numel(alphas)
    a = alphas(ai); rng(o.seed + 101*(ai-1), 'twister');
    cs = 0; cb = 0; v = 0;
    for r = 1:reps
        [y,D] = gen_dgp(N, oci, dci, a, 'binary20', b1);
        f = ppml_2way(y, D, oci, dci);
        if isempty(f), continue; end
        b = f.beta(1); se = f.(['se_' o.studentizer])(1);
        if ~(isfinite(b) && se > 0), continue; end
        v = v + 1;
        cs = cs + (b - Z*se <= b1 && b1 <= b + Z*se);
        [lo,hi] = country_boot_coef(y, D, oci, dci, N, b, se, G, M, o.studentizer);
        if isfinite(lo), cb = cb + (lo <= b1 && b1 <= hi); end
    end
    lab = 'Pareto'; if a >= 2, lab = 'lognormal'; end
    if v > 0, cs_r = cs/v; cb_r = cb/v; else, cs_r = NaN; cb_r = NaN; end
    fprintf('%7.2f %10s %10.3f %13.3f %7d\n', a, lab, cs_r, cb_r, v);
    R(end+1,:) = {a, lab, rnd(cs_r,3), rnd(cb_r,3), v}; %#ok<AGROW>
end
hdr = {'alpha','shock','cov_sandwich','cov_country_boot','reps'};
write_results_csv(fullfile(fileparts(mfilename('fullpath')), ...
    'simulation_results_table3.csv'), hdr, R);
fprintf('wrote simulation_results_table3.csv\n');
end

% =====================================================================
%  Data-generating process (shared)
% =====================================================================
function [oci,dci] = make_pairs(N)
[ii,jj] = find(~eye(N)); oci = ii; dci = jj;
end

function e = shock_draw(n, alpha)
% unit-mean multiplicative shock (both tables)
if alpha < 2
    e = rand(n,1).^(-1/alpha) * (alpha-1)/alpha;          % Pareto(alpha)
else
    s = sqrt(log(1.25)); mu = -0.5*s*s;                   % lognormal, Var=0.25
    e = exp(mu + s*randn(n,1));
end
end

function D = draw_treatment(treat, n)
% 'A' ~ N(0,1); 'B' ~ U[0,4]; 'C' binary 2% (Table 2); 'binary20' 20% (Table 3)
switch treat
    case 'A',        D = randn(n,1);
    case 'B',        D = 4.0*rand(n,1);
    case 'C',        D = double(rand(n,1) < 0.02);
    case 'binary20', D = double(rand(n,1) < 0.20);
    otherwise, error('unknown treatment %s', treat);
end
end

function [y,X] = gen_dgp(N, oci, dci, alpha, treat, b1)
n = numel(oci);
fo = -1 + 2*rand(N,1); fi = -1 + 2*rand(N,1);
D = draw_treatment(treat, n);
mu = exp(fo(oci) + fi(dci) + b1*D);
y = mu .* shock_draw(n, alpha);
X = D;                                    % single Treat regressor
end

% =====================================================================
%  Country-level m-out-of-n bootstrap (single coefficient)  [Table 3]
% =====================================================================
function [lo,hi] = country_boot_coef(y, X, oci, dci, Nc, beta0, se_full, G, M, stud)
T = [];
for j = 1:M
    pick = randperm(Nc, G); inp = false(Nc,1); inp(pick) = true;
    msk = inp(oci) & inp(dci);
    Xs = X(msk);
    if numel(Xs) < 5 || max(Xs) == min(Xs), continue; end % empty/tiny or no variation
    fj = ppml_2way(y(msk), Xs, oci(msk), dci(msk));
    if isempty(fj), continue; end
    bj = fj.beta(1); sj = fj.(['se_' stud])(1);
    if sj > 0 && isfinite(sj) && isfinite(bj), T(end+1) = (bj-beta0)/sj; end %#ok<AGROW>
end
if numel(T) < 20, lo = NaN; hi = NaN; return; end
lo = beta0 - qtile(T, 0.975)*se_full;
hi = beta0 - qtile(T, 0.025)*se_full;
end

% =====================================================================
%  Grouped log-sum-exp (numerically stable FE profiling)
% =====================================================================
function out = group_lse(c, v, K)
m = accumarray(c, v, [K 1], @max, -inf);
out = m + log(accumarray(c, exp(v - m(c)), [K 1]));
end

% =====================================================================
%  Two-way FE Poisson PPML (Sinkhorn profiling + Newton), p>=1 regressors
% =====================================================================
function fit = ppml_2way(y, X, oc, dc)
y = y(:); if isvector(X), X = X(:); end
[n,p] = size(X);
[oc,Ko] = codes(oc); [dc,Kd] = codes(dc);
Ro = accumarray(oc, y, [Ko 1]); Cd = accumarray(dc, y, [Kd 1]);
if any(Ro <= 0) || any(Cd <= 0), fit = []; return; end
logRo = log(Ro); logCd = log(Cd);
la = zeros(Ko,1); lb = zeros(Kd,1); beta = zeros(p,1);
A = zeros(Ko,p); B = zeros(Kd,p); H = eye(p); mu = y; Xt = X;
for it = 1:250
    xb = X*beta;
    if any(~isfinite(xb)) || max(abs(xb)) > 300, fit = []; return; end
    for s = 1:60
        la = logRo - group_lse(oc, lb(dc) + xb, Ko);
        lb_new = logCd - group_lse(dc, la(oc) + xb, Kd);
        if max(abs(lb_new - lb)) < 1e-12, lb = lb_new; break; end
        lb = lb_new;
    end
    mu = exp(la(oc) + lb(dc) + xb);
    smo = accumarray(oc, mu, [Ko 1]); smd = accumarray(dc, mu, [Kd 1]);
    for j = 1:100
        for k = 1:p
            A(:,k) = accumarray(oc, mu.*(X(:,k) - B(dc,k)), [Ko 1]) ./ smo;
        end
        Bn = B;
        for k = 1:p
            Bn(:,k) = accumarray(dc, mu.*(X(:,k) - A(oc,k)), [Kd 1]) ./ smd;
        end
        if max(abs(Bn(:) - B(:))) < 1e-13, B = Bn; break; end
        B = Bn;
    end
    Xt = X - A(oc,:) - B(dc,:);
    g = Xt'*(y - mu); H = (Xt .* mu)' * Xt;
    [step,ok] = safe_solve(H, g, p);
    if ~ok, fit = []; return; end
    mxs = max(abs(X*step)); if mxs > 10, step = step*(10/mxs); end
    t = 1;
    for d = 1:40
        if max(abs(X*(beta + t*step))) <= 250, break; end
        t = t/2;
    end
    beta = beta + t*step;
    if max(abs(t*step)) < 1e-10, break; end
end
res = y - mu; Hi = inv(H);
V = Hi*((Xt .* (res.^2))'*Xt)*Hi;
K = p + (Ko-1) + (Kd-1) + 1;
if n <= K, fit = []; return; end          % no residual dof for a sandwich
dof = n/(n-K);
fit = struct('beta',beta,'se_hc0',sqrt(diag(V)),'se_hc1',sqrt(diag(V)*dof));
end

function [c,K] = codes(a)
[~,~,c] = unique(a); c = c(:); K = max(c);
end

function [step,ok] = safe_solve(H, g, p)
ok = true;
[Rc,flag] = chol(H);
if flag == 0, step = Rc \ (Rc' \ g); return; end
ridge = 1e-9*(trace(H)/p + 1e-12);
step = (H + ridge*eye(p)) \ g;
if any(~isfinite(step)), ok = false; step = zeros(p,1); end
end

% =====================================================================
%  Quantile (linear interpolation) -- avoids the Statistics Toolbox
% =====================================================================
function q = qtile(x, p)
x = sort(x(:)); m = numel(x);
if m == 0, q = NaN; return; end
h = (m-1)*p + 1; lo = floor(h);
if lo >= m, q = x(m); return; end
q = x(lo) + (h - lo)*(x(lo+1) - x(lo));
end

function y = rnd(x, d)
% round to d decimals (base MATLAB and Octave)
y = round(x .* 10.^d) ./ 10.^d;
end

% =====================================================================
%  Manual CSV writer (runs in base MATLAB and Octave)
% =====================================================================
function write_results_csv(path, hdr, R)
fid = fopen(path, 'w');
if fid < 0, error('ppmlmn:io', 'cannot open %s for writing', path); end
fprintf(fid, '%s', hdr{1}); fprintf(fid, ',%s', hdr{2:end}); fprintf(fid, '\n');
for i = 1:size(R,1)
    for k = 1:size(R,2)
        val = R{i,k};
        if k > 1, fprintf(fid, ','); end
        if ischar(val), fprintf(fid, '%s', val); else, fprintf(fid, '%g', val); end
    end
    fprintf(fid, '\n');
end
fclose(fid);
end
